
j=1;
for i=5:1:8640000
    if(mod(i,2)~=0)
        for k=1:1:100
        end  
        for k=1:1:100
        end  
        if(mod(i,3)~=0) 
            for k=1:1:100
            end
            for k=1:1:100
            end  
            if(mod(i,4)~=0) 
                for k=1:1:200
                end
                for k=1:1:100
                end  
                if(mod(i,5)~=0) 
                 a(j)=i;
                 j=j+1;
                end
            end
        end
        
    end
end