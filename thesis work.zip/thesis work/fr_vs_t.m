close all;
clear all;
[audio,fs]=audioread('cough.wav');
audio=audio';
audio=audio(1,:);
f=1/fs;
time=f:f:(f*length(audio));

figure(1)
plot(time,audio);
title('raw audio');
xlabel('time(s)');
ylabel('amplitude');

N=4096;
mid=N/2;
frq=fft(audio,N);
frq_shift=fftshift(frq);
mag=abs(frq_shift);
n=0:N-1;
fHz=n*fs/N;
figure(2)
title('raw fft');
xlabel('frquency');
ylabel('amplitude');
plot(-N/2:N/2-1,mag);

mag_frq_half=abs(frq(1,1:mid));
figure(3)
plot(fHz(1:mid),mag_frq_half);
title('fft');
xlabel('frquency');
ylabel('amplitude');

figure(4)
spectrogram(audio,fs,'yaxis');