close all;
clear all;
[audio,fs]=audioread('sniffle_sample2.wav');
audio=audio';
audio=audio(1,:);
f=1/fs;
%time=f:f:(f*length(audio));

figure(1)
plot(audio);
title('raw audio');
xlabel('time(s)');
ylabel('amplitude');
i=2.613*10^6;
xlim([i i+2*345600]);
% N=4096;
% mid=N/2;
% frq=fft(audio,N);
% frq_shift=fftshift(frq);
% mag=abs(frq_shift);
% n=0:N-1;
% fHz=n*fs/N;
% figure(2)
% title('raw fft');
% xlabel('frquency');
% ylabel('amplitude');
% plot(-N/2:N/2-1,mag);
% 
% mag_frq_half=abs(frq(1,1:mid));
% figure(3)
% plot(fHz(1:mid),mag_frq_half);
% title('fft');
% xlabel('frquency');
% ylabel('amplitude');
% 
% window=hamming(64);
% noverlap=32;
% nfft=1024;
% figure(4)
% [S F T P]=spectrogram(audio,window,noverlap,nfft,fs,'yaxis');
% surf(T,F,10*log10(P),'edgecolor','none');
% % axis tight;
% % view(0,90);
% % colormap(hot);
% % set(gca,'clim',[-80 -30]);
% figure(5)
% spectrogram(audio,window,noverlap,nfft,fs,'yaxis');

