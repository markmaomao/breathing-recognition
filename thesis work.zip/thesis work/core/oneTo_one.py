import scipy.io
import csv
import re
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import copy
from sklearn import linear_model, datasets
from sklearn import datasets
from sklearn import metrics
from sklearn.linear_model import LogisticRegression
from sklearn import cluster,cross_validation
from sklearn.cluster import AgglomerativeClustering
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import confusion_matrix

data = []

with open(r'C:\Users\maomao\Desktop\projectAresuilts\sniffle_slow_py.csv') as file:
    for line in file:
        line = ' '.join(line.split())
        line = line.split(',')
        data.append(line)
mydata = np.matrix(data)

train_whole = np.array(mydata[:, :]).astype(np.float)
#print(train_whole.shape)
results_all = np.array(mydata[:,0]).astype(np.float)
results_all_new=results_all.reshape(170,)
#print(results_all_new.shape)

model = LogisticRegression(penalty='l2', dual=False, tol=0.0001, C=0.1, fit_intercept=True, intercept_scaling=1,
                           class_weight=None, random_state=None, solver='liblinear', max_iter=100, multi_class='ovr')

skf = StratifiedKFold(n_splits=5, random_state=None, shuffle=True)
#container=[]
five=[]
for train, test in skf.split(train_whole, results_all_new):
    # print(train)
    # print(test)
    print(train.shape)
    print(test.shape)
    output = model.fit(train_whole[train], results_all_new[train])
    print(output.predict(train_whole[test]))
    print(results_all_new[test])
    sniffle_slow_confus=confusion_matrix(results_all_new[test], output.predict(train_whole[test]))
    print(sniffle_slow_confus)