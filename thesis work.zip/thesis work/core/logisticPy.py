import scipy.io
import csv
import re
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import copy
from sklearn import linear_model, datasets
from sklearn import datasets
from sklearn import metrics
from sklearn.linear_model import LogisticRegression
from sklearn import cluster,cross_validation
from sklearn.cluster import AgglomerativeClustering
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV

data = []
data_sample = []

with open(r'D:\project B\downsample\All_gestures_combine_nosamples.csv') as file:
    for line in file:
        line = ' '.join(line.split())
        line = line.split(',')
        data.append(line)
mydata = np.array(data)
#print(mydata)
index=0
for line in mydata[:,0]:
    if int(line) !=4:
       mydata[index,0]=0
    else:
        print(index)
    index = index + 1
#print(mydata)

# def write_csv(file_name):
#     csv_open=open(file_name,'w')
#     writer=csv.writer(csv_open)
#     for line in mydata:
#         writer.writerow(line)
#     csv_open.close()
# file='D:\project B\downsample\mydata_normal.csv'
# write_csv(file)

train_whole = np.array(mydata[:, 1:]).astype(np.float)
print(train_whole.shape)
results_all = np.array(mydata[:,0]).astype(np.float)
results_all_new=results_all.reshape(515,)
print(results_all_new.shape)

model = LogisticRegression()

# # skf = StratifiedKFold(n_splits=5, random_state=None, shuffle=True)

parameters = {'tol':[1,0.1,0.01,0.001,0.0001, 0.00001,0.000001,0.0000001,0.00000001,math.pow(10,-9),math.pow(10,-10)], 'C':[0.001,0.01,0.1,1,10,100,1000,10000,100000,1000000,math.pow(10,8)]}
# # # for train, test in skf.split(train_whole, results_all_new):
# # #    #print(train)
# # #    #print(test)
# # #    print(train.shape)
# # #     print(test.shape)
# # #     output = model.fit(train_whole[train], results_all_new[train])
# # #     print(output.predict(train_whole[test]))
# # #     print(results_all_new[test])
# # #     slow_all_confus=confusion_matrix(results_all_new[test], output.predict(train_whole[test]))
# # #     print(slow_all_confus)

clf = GridSearchCV(model, parameters,cv=5)
output_param = clf.fit(train_whole, results_all_new)
best_para=dict(clf.best_estimator_.get_params())
print(best_para['tol'])
print(best_para['C'])

L_model=LogisticRegression(tol=best_para['tol'],C=best_para['C'])
model_new=L_model.fit(train_whole,results_all_new)
weight_list=model_new.coef_
print(weight_list)

feature_name = []
with open(r"C:\Users\maomao\Desktop\projectAresuilts\python_input_py.csv") as file:
    feature_name = (file.readlines()[0])
    feature_name=feature_name.split(',')
    feature_name=feature_name[1:]

lis1=[]
lis2=[]
#print(weight_list)
print(feature_name)
print(len(weight_list[0]))
print(len(feature_name))
zip_list=zip(feature_name, weight_list[0])
ranking = list(zip_list)
print(ranking)
ranking.sort(key=lambda x:x[1],reverse=True)
print(ranking)
# # for i in range(len(weight_list[0])):
# #     lis1.append(weight_list[0][i])
# #     lis1.append(feature_name[i])
# #     lis2.append(lis1)
# #     lis1=[]
# # print(lis2)
# #
# # lis2.sort(key=lambda x:x[1])
# # print(lis2)

testdata = []
mytestdata = []
with open(r'D:\project B\downsample\All_gestures_combine_mysamples.csv') as file:
    for line in file:
        line = ' '.join(line.split())
        line = line.split(',')
        testdata.append(line)
mytestdata = np.array(testdata)

#print(np.array(mytestdata[:, 1:]).shape)
test_samples = np.array(mytestdata[:, 1:]).astype(np.float)
print(test_samples.shape)

optimal_result = model_new.predict(test_samples)
print(optimal_result)
# # # slow_all_confus=confusion_matrix(results_all_new, output_param.predict(sample_train))
# # # print(slow_all_confus)
# # # print(skf)





