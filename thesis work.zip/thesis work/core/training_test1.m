close all;
clear all;
% namelist1 = dir('D:\project B\training\user1\deep\*.wav');
% namelist2 = dir('D:\project B\training\user2\deep\*.wav');
% namelist3 = dir('D:\project B\training\user3\deep\*.wav');
% namelist4 = dir('D:\project B\training\user4\deep\*.wav');
% namelist7 = dir('D:\project B\training\user7\deep\*.wav');
% namelist8 = dir('D:\project B\training\user8\deep\*.wav');
% namelist10 = dir('D:\project B\training\user10\deep\*.wav');
% namelist11 = dir('D:\project B\training\user11\deep\*.wav');
% namelist12 = dir('D:\project B\training\user12\deep\*.wav');
% namelist14 = dir('D:\project B\training\user14\deep\*.wav');
namelist1 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user1\test5\*.wav');
namelist2 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user2\test5\*.wav');
namelist3 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user3\test5\*.wav');
namelist4 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user4\test5\*.wav');
namelist7 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user7\test5\*.wav');
namelist8 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user8\test5\*.wav');
namelist10 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user10\test5\*.wav');
namelist11 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user11\test5\*.wav');
namelist12 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user12\test5\*.wav');
namelist14 = dir('D:\project B\training\testing_data_dropbox\testing_data_dropbox\testing\user14\test5\*.wav');
file_name = {namelist1.name;namelist2.name;namelist3.name;namelist4.name;namelist7.name;
    namelist8.name;namelist10.name;namelist11.name;namelist12.name;namelist14.name};
file_name = file_name';
data_form = zeros(1,58);
for i=91:100
        shift_number = 150;
        shift_length = 0;
        %read audio file
        [audio,fs] = audioread(file_name{i});
        audio = audio';
        %peak value calculation
        peakValue = max(audio);
        %RMS calculation
        RMSvalue = rms(audio);
        %frequency calculation
        frequency = 1/(length(audio)/8000);
        %power caculation
        %In time domain: for discrete signal x(n)
        %Instantaneous power = x(n)^2
        %Average power = (1/N) * sum(|x(n)|.^2)
        %N = data length or period
        ave_pw1 = (audio);
        ave_pw2 = length(audio);
        AveragePower = (1/(ave_pw2))*sum(ave_pw1.^2);
        %zero crossing rate calculation, ZCR=mean(abs(diff(sign(Signal)));
        ZCR = sum(abs(diff(audio>0)))/length(audio);
        %MFCC calculation
        myMFCC=zeros(13,shift_number);
        combineMFCC = zeros(52);
        combineMFCC_temp= 0;
        shift_length = (1000*length(audio)/(fs) - 50)/shift_number;
        [ CC, FBE, frames ] = mfcc( audio, fs,50, shift_length, 1, window, [0 5000], 20, 13, 22 );
        myMFCC(:,:)=CC(1:13,1:150);
        aveMFCC = zeros(1,13);
        pkMFCC = zeros(1,13);
        medMFCC = zeros(1,13);
        sdMFCC = zeros(1,13);
        for j=1:1:13
            aveMFCC(1,j) = sum(myMFCC(j,:))/shift_number;
            pkMFCC(1,j) = max(myMFCC(j,:));
            medMFCC(1,j) = median(myMFCC(j,:));
            sdMFCC(1,j) = std(myMFCC(j,:));
            combineMFCC_temp = [aveMFCC pkMFCC medMFCC sdMFCC];
        end
        combineMFCC=combineMFCC_temp;
        five_data = [peakValue; AveragePower; RMSvalue; frequency; ZCR];
        %combine matrix
        five_data=five_data';
        new=[14 five_data];
        user14_test = [new combineMFCC];
        data_form = [data_form; user14_test];
end
data_formT14 = data_form(2:11,:);