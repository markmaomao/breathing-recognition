import scipy.io
import csv
import re
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import copy
from sklearn import linear_model, datasets
from sklearn import datasets
from sklearn import metrics
from sklearn.linear_model import LogisticRegression
from sklearn import cluster,cross_validation
from sklearn.cluster import AgglomerativeClustering
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn import svm
from sklearn.svm import LinearSVC
data = []
data_sample = []

with open(r'D:\project B\training\userTrainning80.csv') as file:
    for line in file:
        line = ' '.join(line.split())
        line = line.split(',')
        data.append(line)
mydata = np.array(data)
print(mydata)
# index=0
# for line in mydata[:,0]:
#     if int(line) !=1:
#        mydata[index,0]=0
#     else:
#         print(index)
#     index = index + 1
#print(mydata)
train_whole = np.array(mydata[:, 1:]).astype(np.float)
print(train_whole.shape)
results_all = np.array(mydata[:,0]).astype(np.float)
results_all_new=results_all.reshape(400,)
print(results_all_new.shape)

#model = svm.LinearSVC()
model = svm.SVC(kernel='rbf')

parameters = {'C':[0.001,0.01,0.1,1,10,100,1000,10000,100000,1000000,math.pow(10,8)]}
cross_vld = GridSearchCV(model, parameters,cv=5)
output_param = cross_vld.fit(train_whole, results_all_new)
best_para=dict(cross_vld.best_estimator_.get_params())
print(best_para['C'])

#SVM_model = svm.SVC(C=best_para['C'],kernel='sigmoid')
#SVM_model = svm.SVC(C=best_para['C'],kernel='poly')
SVM_model = svm.SVC(C=best_para['C'],kernel='rbf')
#SVM_model = svm.SVC(C=best_para['C'],kernel='linear')
#SVM_model = svm.LinearSVC(C=best_para['C'])
clf = SVM_model.fit(train_whole,results_all_new)

testdata = []
mytestdata = []
with open(r'D:\project B\training\userTest.csv') as file:
    for line in file:
        line = ' '.join(line.split())
        line = line.split(',')
        testdata.append(line)
mytestdata = np.array(testdata)

print(mytestdata[:,1:])
test_samples = np.array(mytestdata[:, 1:]).astype(np.float)
print(test_samples.shape)
svm_result = clf.predict(test_samples)
print(svm_result)

Ground_truth = np.array(mytestdata[:, 0]).astype(np.float)
print(Ground_truth)
#confusion_linear = confusion_matrix(Ground_truth,svm_result)
confusion_rbf = confusion_matrix(Ground_truth,svm_result)
#confusion_poly = confusion_matrix(Ground_truth,svm_result)
#confusion_sigmoid = confusion_matrix(Ground_truth,svm_result)
print(confusion_rbf)