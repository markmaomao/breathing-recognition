close all;
clear all;
actual_length = 0;
%read data from normal sample1
[audio,fs]=audioread('slow_sample1.wav');
audio=audio';
%peak value calculation
startPoint = xlsread('data_slow.xlsx','Sheet1','B2:B10');
endPoint = xlsread('data_slow.xlsx','Sheet1','C2:C10');
startPoint = startPoint';
endPoint = endPoint';
pattern = 9;
peakValue = zeros(1,pattern);
shift_number = 150;
shift_length = 0;
%downsample_file = downsample(audio(1,startPoint(1,i):endPoint(1,i)),5);
%downsample_file_reverse = downsample(length(endPoint(1,i)-startPoint(1,i)),5);
for i=1:1:pattern
    down_peakPoint = downsample(audio(1,startPoint(1,i):endPoint(1,i)),5);
    peakValue(1,i) = max(down_peakPoint);
end 
%RMS calculation
RMSvalue = zeros(1,pattern);
for i=1:1:pattern
    down_RMS = downsample(audio(1,startPoint(1,i):endPoint(1,i)),5);
    RMSvalue(1,i) = rms(down_RMS);
end 
%frequency calculation
frequency = zeros(1,pattern);
for i=1:1:pattern
    down_frq = downsample((endPoint(1,i)-startPoint(1,i)),5);
    frequency(1,i) = 1/(down_frq/8820);
end
%power caculation
%In time domain: for discrete signal x(n)
%Instantaneous power = x(n)^2
%Average power = (1/N) * sum(|x(n)|.^2)
%N = data length or period
AveragePower = zeros(1,pattern);
for i=1:1:pattern
    down_ave_pw1 = downsample(audio(1,startPoint(1,i):endPoint(1,i)),5);
    down_ave_pw2 = downsample((endPoint(1,i)-startPoint(1,i)),5);
    AveragePower(1,i) = (1/(down_ave_pw2))*sum(down_ave_pw1.^2);
end
%zero crossing rate calculation, ZCR=mean(abs(diff(sign(Signal)));
ZCR = zeros(1,pattern);
for i=1:1:pattern
    down_zcr = downsample(audio(1,startPoint(1,i):endPoint(1,i)),5);
    ZCR(1,i) = sum(abs(diff(down_zcr>0)))/length(down_zcr);
end
%MFCC calculation
myMFCC=zeros(13,shift_number,pattern);
combineMFCC = zeros(pattern,52);
for i=1:1:pattern
    down_mfcc = downsample(audio(1,startPoint(1,i):endPoint(1,i)),5);
    combineMFCC_temp= 0;
    shift_length = (1000*length(down_mfcc)/(fs/5) - 50)/shift_number;
    %shift_length = floor(shift_length);
    %actual_length = (fs/5)*(50+150*shift_length)/1000;
    %actual_length=46000;
    %actual_down_mfcc = down_mfcc(1,1:actual_length);
[ CC, FBE, frames ] = mfcc( down_mfcc, (fs/5),50, shift_length, 1, window, [0 5000], 20, 13, 22 );
    myMFCC(:,:,i)=CC(1:13,1:150);
    aveMFCC = zeros(1,13);
    pkMFCC = zeros(1,13);
    medMFCC = zeros(1,13);
    sdMFCC = zeros(1,13);
    for j=1:1:13
       aveMFCC(1,j) = sum(myMFCC(j,:,i))/shift_number;
       pkMFCC(1,j) = max(myMFCC(j,:,i));
       medMFCC(1,j) = median(myMFCC(j,:,i));
       sdMFCC(1,j) = std(myMFCC(j,:,i));
       combineMFCC_temp = [aveMFCC pkMFCC medMFCC sdMFCC];
    end
    combineMFCC(i,:)=combineMFCC_temp;
end

preSlow_A = [peakValue; AveragePower; RMSvalue; frequency; ZCR];
%combine matrix
preSlow_A=preSlow_A';
preSlow_A=[5*ones(length(preSlow_A),1) preSlow_A];
Slow_A = [preSlow_A combineMFCC];